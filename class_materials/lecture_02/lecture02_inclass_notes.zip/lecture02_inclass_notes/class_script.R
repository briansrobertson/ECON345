#Lecture 2 in-class examples

install.packages('tidyverse')
install.packages('fredr')
library(tidyverse)
library(fredr)

#from FRED, my personal API key
FRED_API_KEY='YOURKEYHERE'

#package::function allows us to call that function
#directly from the library, helpful if you have
#two functions with the same name

fredr::fredr_set_key(FRED_API_KEY)

unrate_data <- fredr(
  series_id = "UNRATE"
) 


#mutate - we are changing the value of individual observations
unrate_df <- unrate_data %>%
  select(date,value) %>%
  mutate(unemp_pct=value/100)

#summarize - we are "summarizing" the collection of observations into 
#an individual statistic "basic stats"

#how to deal with NAs
unrate_df %>%
  summarize(avg_unemp=mean(value,na.rm=TRUE))
  
unrate_avg <- unrate_df %>%
  filter(!is.na(value)) %>%
  summarize(avg_unemp=mean(unemp_pct))

#avg unemployment by decade

decade_avg <- unrate_df %>%
  mutate(decade = (year(date) %/% 10)*10) %>%
  group_by(decade) %>%
  summarize(avg_unemp=mean(value,na.rm=TRUE)) %>%
  mutate(
    lag_unemp=lag(avg_unemp),
    lead_unemo=lead(avg_unemp)
    )

#code chunk to illustrate a filter based on the
#membership to a list of values
filter(value %in% c('name1','name2','name3'))

#wide vs long using our homework data
decade_pop<-read_csv('data/decade_pop.csv')

#convert "wide" data to "long"
decade_pop %>%
  pivot_longer(
    c(Black,White),
    values_to='population',
    names_to='race'
    )



